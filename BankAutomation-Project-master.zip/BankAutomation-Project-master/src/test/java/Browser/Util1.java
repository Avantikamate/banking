package Browser;

public class Util1 {
	
	public static final String FIREFOX_PATH = "C:\\Users\\nlimb\\Eclipse_nSel\\Bank_Automation\\drivers\\firefoxDriver\\geckodriver.exe";
	
	public static final String BASE_URL ="http://www.demo.guru99.com/";
	
	//Valid Login Credentials
	public static final String USER_NAME ="mngr219136";
	public static final String PASSWORD = "ujYvEbY";
	
	public static final int WAIT_TIME = 30;
	public static final String EXPECTED_TITLE = "Guru99 Bank Manager HomePage";
	public static final String EXPECTED_ERROR ="User or Password is not valid";
	
	public static final String PATTERN = ":";
	public static final String FIRST_PATTERN = "mngr";
	public static final String SECOND_PATTERN ="[0-9]+";
	
}
